import Alex
import Tokens

main:: IO ()
main = interact (show.tokens)
