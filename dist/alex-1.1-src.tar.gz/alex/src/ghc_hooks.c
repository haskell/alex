#include <stdio.h>

void ErrorHdrHook(chan)
     FILE *chan;
{}
